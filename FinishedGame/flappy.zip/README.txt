IN A CONFIGURATION FILE YOU CAN CHANGE PARAMETERS:
1) Vertical distance between pipes
	1.1) EASY default 150
	1.2) MEDIUM default 135
	1.3) HARD default 120
2) Horizontal distance between pipes
	2.1)DISTANCE default 230
3) The number of players
	3.1) NUMBER 1 or 2

STEERING:
1) Menu - ARROWS and RETURN
2) Player1 - SPACE
3) Player2 - LSHIFT 
	